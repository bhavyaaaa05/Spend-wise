const CAT_COLORS = { Food:'#e8722a', Travel:'#2980b9', Bills:'#8e44ad', Other:'#27ae60' };

let expenses = [];
let budgets  = {};

async function loadData() {
  const [expRes, budRes] = await Promise.all([
    fetch('/api/expenses'), fetch('/api/budgets')
  ]);
  expenses = await expRes.json();
  budgets  = await budRes.json();
  renderSummary(); renderList(); renderBudgets();
}

async function addExpense() {
  const amount   = document.getElementById('amount').value;
  const note     = document.getElementById('note').value || 'Expense';
  const category = document.getElementById('category').value;
  const date     = document.getElementById('date').value || new Date().toISOString().slice(0,10);

  const today = new Date().toISOString().slice(0,10);

  // ✅ Frontend validation
  if (date > today) {
    return alert("❌ Future date is not allowed");
  }

  if (!amount || amount <= 0) {
    return alert("Enter a valid amount");
  }

  const res = await fetch('/api/expenses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ amount, note, category, date })
  });

  // ✅ Handle backend error
  if (!res.ok) {
    const err = await res.json();
    return alert("❌ " + err.error);
  }

  document.getElementById('amount').value = '';
  document.getElementById('note').value   = '';

  loadData();
}

async function deleteExpense(id) {
  await fetch(`/api/expenses/${id}`, { method: 'DELETE' });
  loadData();
}

async function updateBudget(category, amount) {
  await fetch('/api/budgets', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ category, amount: parseFloat(amount) })
  });
  loadData();
}

function fmt(n) {
  return '₹' + parseFloat(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

function renderSummary() {
  const month = new Date().toISOString().slice(0,7);
  const mExp  = expenses.filter(e => e.date.startsWith(month));
  const total = mExp.reduce((s,e) => s + e.amount, 0);

  const top = Object.keys(CAT_COLORS).reduce((a,b) => {
    const sa = mExp.filter(e=>e.category===a).reduce((s,e)=>s+e.amount,0);
    const sb = mExp.filter(e=>e.category===b).reduce((s,e)=>s+e.amount,0);
    return sb > sa ? b : a;
  }, 'Food');

  document.getElementById('summary-grid').innerHTML = `
    <div class="stat"><div class="label">This Month</div><div class="value">${fmt(total)}</div></div>
    <div class="stat"><div class="label">Transactions</div><div class="value">${mExp.length}</div></div>
    <div class="stat"><div class="label">Top Category</div>
      <div class="value" style="color:${CAT_COLORS[top]};font-size:1rem">${top}</div></div>
  `;
}

function renderList() {
  const q = (document.getElementById('search').value || '').toLowerCase();

  const list = expenses.filter(e =>
    !q || e.note.toLowerCase().includes(q) || e.category.toLowerCase().includes(q)
  );

  const el = document.getElementById('expense-list');

  if (!list.length) {
    el.innerHTML = '<p style="color:#aaa;padding:1rem 0;font-size:13px">No expenses yet.</p>';
    return;
  }

  el.innerHTML = list.map(e => `
    <div class="expense-item">
      <div class="dot" style="background:${CAT_COLORS[e.category]}"></div>
      <div class="exp-info">
        <div class="exp-name">${e.note}</div>
        <div class="exp-meta">${e.category} · ${e.date}</div>
      </div>
      <div class="exp-amt">${fmt(e.amount)}</div>
      <button class="del-btn" onclick="deleteExpense(${e.id})">✕</button>
    </div>
  `).join('');
}

function renderBudgets() {
  const month = new Date().toISOString().slice(0,7);
  const mExp  = expenses.filter(e => e.date.startsWith(month));

  document.getElementById('budget-section').innerHTML =
    Object.keys(CAT_COLORS).map(cat => {
      const spent = mExp.filter(e=>e.category===cat).reduce((s,e)=>s+e.amount,0);
      const bud   = budgets[cat] || 0;

      const pct  = bud > 0 ? Math.min(Math.round(spent/bud*100), 100) : 0;
      const over = spent > bud;

      return `
        <div class="budget-row">
          <label>${cat}
            <input type="number" value="${bud}" onchange="updateBudget('${cat}', this.value)">
          </label>

          <span style="font-size:11px;color:${over?'#e74c3c':'#888'};margin-left:8px">
            ${fmt(spent)} / ${fmt(bud)} ${over ? '⚠ over budget' : ''}
          </span>

          <div class="bar-track">
            <div class="bar-fill" style="width:${pct}%;background:${over?'#e74c3c':CAT_COLORS[cat]}"></div>
          </div>
        </div>
      `;
    }).join('');
}

// ✅ Set today's date and block future selection
const today = new Date().toISOString().slice(0,10);
document.getElementById('date').value = today;
document.getElementById('date').max   = today;

loadData();
